import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_name='hotel_booking.db'):
        self.db_name = db_name
        self.init_database()

    def get_connection(self):
        return sqlite3.connect(self.db_name)

    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()

        # Таблица комнат
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number TEXT UNIQUE NOT NULL,
                room_type TEXT NOT NULL,
                price_per_night REAL NOT NULL,
                capacity INTEGER NOT NULL,
                description TEXT,
                is_available BOOLEAN DEFAULT TRUE
            )
        ''')

        # Таблица клиентов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                phone TEXT NOT NULL
            )
        ''')

        # Таблица бронирований
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id INTEGER NOT NULL,
                customer_id INTEGER NOT NULL,
                check_in_date TEXT NOT NULL,
                check_out_date TEXT NOT NULL,
                total_price REAL NOT NULL,
                status TEXT DEFAULT 'confirmed',
                created_at TEXT NOT NULL,
                FOREIGN KEY (room_id) REFERENCES rooms (id),
                FOREIGN KEY (customer_id) REFERENCES customers (id)
            )
        ''')

        # Добавляем тестовые данные
        self._add_sample_data(cursor)

        conn.commit()
        conn.close()

    def _add_sample_data(self, cursor):
        # Проверяем, есть ли уже данные
        cursor.execute("SELECT COUNT(*) FROM rooms")
        if cursor.fetchone()[0] == 0:
            # Добавляем комнаты
            rooms = [
                ('101', 'Standard', 50.0, 2, 'Комфортабельный стандартный номер с одной кроватью'),
                ('102', 'Standard', 50.0, 2, 'Комфортабельный стандартный номер с одной кроватью'),
                ('201', 'Deluxe', 80.0, 3, 'Просторный номер с видом на город'),
                ('202', 'Deluxe', 80.0, 3, 'Просторный номер с видом на город'),
                ('301', 'Suite', 120.0, 4, 'Роскошный люкс с гостиной зоной'),
                ('302', 'Suite', 120.0, 4, 'Роскошный люкс с гостиной зоной')
            ]

            cursor.executemany('''
                INSERT INTO rooms (number, room_type, price_per_night, capacity, description)
                VALUES (?, ?, ?, ?, ?)
            ''', rooms)

    # Методы для работы с комнатами
    def get_all_rooms(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, number, room_type, price_per_night, capacity, description, is_available 
            FROM rooms
        ''')
        rooms = cursor.fetchall()
        conn.close()
        return rooms

    def get_available_rooms(self, check_in_date=None, check_out_date=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        if check_in_date and check_out_date:
            # Ищем комнаты, которые не забронированы на указанные даты
            cursor.execute('''
                SELECT r.* FROM rooms r
                WHERE r.is_available = TRUE
                AND r.id NOT IN (
                    SELECT b.room_id FROM bookings b
                    WHERE b.status = 'confirmed'
                    AND (
                        (b.check_in_date <= ? AND b.check_out_date >= ?) OR
                        (b.check_in_date <= ? AND b.check_out_date >= ?) OR
                        (b.check_in_date >= ? AND b.check_out_date <= ?)
                    )
                )
            ''', (check_out_date, check_in_date, check_in_date, check_out_date, check_in_date, check_out_date))
        else:
            cursor.execute('SELECT * FROM rooms WHERE is_available = TRUE')
        
        rooms = cursor.fetchall()
        conn.close()
        return rooms

    def get_room_by_id(self, room_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM rooms WHERE id = ?', (room_id,))
        room = cursor.fetchone()
        conn.close()
        return room

    # Методы для работы с клиентами
    def add_customer(self, first_name, last_name, email, phone):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO customers (first_name, last_name, email, phone)
                VALUES (?, ?, ?, ?)
            ''', (first_name, last_name, email, phone))
            customer_id = cursor.lastrowid
            conn.commit()
            return customer_id
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()

    def get_customer_by_email(self, email):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM customers WHERE email = ?', (email,))
        customer = cursor.fetchone()
        conn.close()
        return customer

    # Методы для работы с бронированиями
    def create_booking(self, room_id, customer_id, check_in_date, check_out_date, total_price):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        created_at = datetime.now().isoformat()
        
        cursor.execute('''
            INSERT INTO bookings (room_id, customer_id, check_in_date, check_out_date, total_price, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'confirmed', ?)
        ''', (room_id, customer_id, check_in_date, check_out_date, total_price, created_at))
        
        booking_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return booking_id

    def get_booking_by_id(self, booking_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT b.*, r.number, r.room_type, c.first_name, c.last_name 
            FROM bookings b
            JOIN rooms r ON b.room_id = r.id
            JOIN customers c ON b.customer_id = c.id
            WHERE b.id = ?
        ''', (booking_id,))
        booking = cursor.fetchone()
        conn.close()
        return booking

    def cancel_booking(self, booking_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE bookings SET status = "cancelled" WHERE id = ?', (booking_id,))
        conn.commit()
        conn.close()

    def get_all_bookings(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT b.*, r.number, r.room_type, c.first_name, c.last_name 
            FROM bookings b
            JOIN rooms r ON b.room_id = r.id
            JOIN customers c ON b.customer_id = c.id
            ORDER BY b.created_at DESC
        ''')
        bookings = cursor.fetchall()
        conn.close()
        return bookings
    