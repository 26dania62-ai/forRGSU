from booking_system import BookingSystem

def main():
    system = BookingSystem()
    
    while True:
        system.display_menu()
        choice = input("\nВыберите опцию (1-5): ")
        
        if choice == '1':
            check_in = input("Дата заезда (ГГГГ-ММ-ДД) или Enter для всех дат: ")
            check_out = input("Дата выезда (ГГГГ-ММ-ДД) или Enter для всех дат: ")
            
            if check_in and check_out:
                system.display_available_rooms(check_in, check_out)
            else:
                system.display_available_rooms()
                
        elif choice == '2':
            system.create_booking()
            
        elif choice == '3':
            system.view_all_bookings()
            
        elif choice == '4':
            system.cancel_booking()
            
        elif choice == '5':
            print("Выход из системы...")
            break
            
        else:
            print("Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    main()