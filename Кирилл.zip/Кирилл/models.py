from datetime import datetime
from dataclasses import dataclass
from typing import Optional

@dataclass
class Room:
    id: int
    number: str
    room_type: str
    price_per_night: float
    capacity: int
    description: str
    is_available: bool = True

@dataclass
class Customer:
    id: int
    first_name: str
    last_name: str
    email: str
    phone: str

@dataclass
class Booking:
    id: int
    room_id: int
    customer_id: int
    check_in_date: str
    check_out_date: str
    total_price: float
    status: str  # 'confirmed', 'cancelled', 'completed'
    created_at: str