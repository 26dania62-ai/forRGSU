from database import Database
from datetime import datetime, timedelta

class BookingSystem:
    def __init__(self):
        self.db = Database()

    def display_available_rooms(self, check_in_date=None, check_out_date=None):
        """Показать доступные комнаты"""
        rooms = self.db.get_available_rooms(check_in_date, check_out_date)
        
        if not rooms:
            print("Нет доступных комнат")
            return
        
        print("\nДоступные комнаты:")
        print("-" * 80)
        print(f"{'ID':<3} {'Номер':<6} {'Тип':<10} {'Цена/ночь':<12} {'Вместимость':<12} {'Описание'}")
        print("-" * 80)
        
        for room in rooms:
            print(f"{room[0]:<3} {room[1]:<6} {room[2]:<10} ${room[3]:<11.2f} {room[4]:<12} {room[5]}")

    def calculate_total_price(self, room_id, check_in_date, check_out_date):
        """Рассчитать общую стоимость бронирования"""
        room = self.db.get_room_by_id(room_id)
        if not room:
            return 0
        
        # Преобразуем строки в даты
        check_in = datetime.strptime(check_in_date, '%Y-%m-%d')
        check_out = datetime.strptime(check_out_date, '%Y-%m-%d')
        
        # Вычисляем количество ночей
        nights = (check_out - check_in).days
        if nights <= 0:
            return 0
        
        return room[3] * nights

    def create_booking(self):
        """Создать новое бронирование"""
        print("\n--- Создание нового бронирования ---")
        
        # Получаем даты
        check_in_date = input("Дата заезда (ГГГГ-ММ-ДД): ")
        check_out_date = input("Дата выезда (ГГГГ-ММ-ДД): ")
        
        # Проверяем доступные комнаты
        available_rooms = self.db.get_available_rooms(check_in_date, check_out_date)
        if not available_rooms:
            print("Нет доступных комнат на указанные даты")
            return
        
        self.display_available_rooms(check_in_date, check_out_date)
        
        try:
            room_id = int(input("\nВыберите ID комнаты для бронирования: "))
            
            # Проверяем, что комната доступна
            room_exists = any(room[0] == room_id for room in available_rooms)
            if not room_exists:
                print("Неверный ID комнаты или комната недоступна")
                return
        except ValueError:
            print("Неверный формат ID")
            return
        
        # Данные клиента
        print("\n--- Информация о клиенте ---")
        first_name = input("Имя: ")
        last_name = input("Фамилия: ")
        email = input("Email: ")
        phone = input("Телефон: ")
        
        # Добавляем клиента или получаем существующего
        customer = self.db.get_customer_by_email(email)
        if customer:
            customer_id = customer[0]
            print(f"Найден существующий клиент: {customer[1]} {customer[2]}")
        else:
            customer_id = self.db.add_customer(first_name, last_name, email, phone)
            if not customer_id:
                print("Ошибка при добавлении клиента")
                return
        
        # Рассчитываем стоимость
        total_price = self.calculate_total_price(room_id, check_in_date, check_out_date)
        
        # Подтверждение
        print(f"\nОбщая стоимость: ${total_price:.2f}")
        confirm = input("Подтвердить бронирование? (y/n): ")
        
        if confirm.lower() == 'y':
            booking_id = self.db.create_booking(room_id, customer_id, check_in_date, check_out_date, total_price)
            print(f"Бронирование создано успешно! ID бронирования: {booking_id}")
        else:
            print("Бронирование отменено")

    def view_all_bookings(self):
        """Показать все бронирования"""
        bookings = self.db.get_all_bookings()
        
        if not bookings:
            print("Нет бронирований")
            return
        
        print("\nВсе бронирования:")
        print("-" * 120)
        print(f"{'ID':<3} {'Комната':<8} {'Тип':<10} {'Клиент':<20} {'Заезд':<12} {'Выезд':<12} {'Стоимость':<10} {'Статус':<12}")
        print("-" * 120)
        
        for booking in bookings:
            print(f"{booking[0]:<3} {booking[8]:<8} {booking[9]:<10} {booking[11] + ' ' + booking[10]:<20} "
                  f"{booking[3]:<12} {booking[4]:<12} ${booking[5]:<9.2f} {booking[6]:<12}")

    def cancel_booking(self):
        """Отменить бронирование"""
        try:
            booking_id = int(input("Введите ID бронирования для отмены: "))
            booking = self.db.get_booking_by_id(booking_id)
            
            if not booking:
                print("Бронирование не найдено")
                return
            
            print(f"Бронирование #{booking[0]}: {booking[8]} - {booking[11]} {booking[10]}")
            confirm = input("Вы уверены, что хотите отменить бронирование? (y/n): ")
            
            if confirm.lower() == 'y':
                self.db.cancel_booking(booking_id)
                print("Бронирование отменено")
            else:
                print("Отмена операции")
                
        except ValueError:
            print("Неверный формат ID")

    def display_menu(self):
        """Показать главное меню"""
        print("\n=== Система бронирования комнат ===")
        print("1. Показать доступные комнаты")
        print("2. Создать бронирование")
        print("3. Показать все бронирования")
        print("4. Отменить бронирование")
        print("5. Выход")